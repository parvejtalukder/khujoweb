document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("search-form").addEventListener("submit", function (event) {
        let searchInput = document.getElementById("search-input").value.trim();
        let bengaliRegex = /^[\u0980-\u09FF\s\d.,"'`;:\]\[}{|\\/~`@#$%^&*()_=+!-]+$/;

        if (!bengaliRegex.test(searchInput) || searchInput === "") {
            event.preventDefault(); // Stop form submission
            alert("অনুগ্রহ করে শুধুমাত্র বাংলা ভাষায় সার্চ করুন!");
        }
    });
});
