<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>শর্তাবলী - খুঁজোওয়েব</title>
    <meta name="description" content="খুঁজোওয়েব হলো বাংলা ভাষাভাসি সম্প্রদায়ের জন্য একটি নিরাপদ অনুসন্ধান ইঞ্জিন, যা ইন্টারনেটে থাকা বাংলা ভাষার ওয়েবসাইটসমূহে অনুসন্ধান চালিয়ে মুহূর্তেই আপনার জন্য নিরাপদ তথ্য হাজির করে।">
    <meta http-equiv="cache-control" content="max-age=0" >
    <meta http-equiv="cache-control" content="no-cache" >
    <meta http-equiv="expires" content="0" >
    <meta http-equiv="expires" content="Tue, 01 Jan 1980 1:00:00 GMT">
    <meta http-equiv="pragma" content="no-cache" >
    <meta name="robots" content="NOODP">
    <meta name="keywords" content="গুগল, বাংলা, সার্চ, শিশু, নিরাপদ, সার্চ ইঞ্জিন">
    <link rel="stylesheet" href="style.css">
    <script src="script.js" defer></script>
    <link rel="shortcut icon" href="https://blog.khujoweb.com/wp-content/uploads/2025/01/kw.png">
    <link rel="icon" type="image/png" href="https://blog.khujoweb.com/wp-content/uploads/2025/01/cropped-cropped-Khujoweb-Icon.png" sizes="16x16">
    <link rel="apple-touch-icon" sizes="180x180" href="https://blog.khujoweb.com/wp-content/uploads/2025/01/cropped-cropped-Khujoweb-Icon.png">
</head>
<body>
    <div class="wrapper">
        <!-- Logo -->
        <div class="logo">
    <a href="https://bn.khujoweb.com">
        <img src="https://bn.khujoweb.com/kwb.png" alt="খুঁজোওয়েব লোগো" class="logo-img">
    </a>
</div>
        <!-- About Section -->
        <div class="about-section">
            <h2>শর্তাবলী</h2>
            <p>আপনি খুঁজোওয়েব ব্যবহার করে এই শর্তাবলীতে সম্মতি জানাচ্ছেন। যদি আপনি এই শর্তাবলীর সাথে একমত না হন, তবে অনুগ্রহ করে আমাদের পরিষেবা ব্যবহার করবেন না। খুঁজোওয়েব একটি বাংলা ভাষাভিত্তিক সার্চ ইঞ্জিন যা আপনাকে নির্দিষ্ট ওয়েবসাইট থেকে তথ্য খুঁজে পেতে সহায়তা করে। আপনি খুঁজোওয়েব ব্যবহার করার সময় কোনো অবৈধ, আপত্তিকর, ক্ষতিকর বা বিভ্রান্তিকর কনটেন্ট পাবার সম্ভাবনা কম, তার পরও এমন কন্টেন্ট আসলে আমরা জন্য দায়ী নই।

আমাদের সাইটে প্রদর্শিত অধিকাংশ তথ্য বাহ্যিক ওয়েবসাইট থেকে সংগৃহীত হয় এবং খুঁজোওয়েব এসব কনটেন্টের মালিক নয়। বাহ্যিক ওয়েবসাইটগুলোর নিজস্ব কপিরাইট এবং শর্তাবলী প্রযোজ্য, যা আপনাকে মেনে চলতে হবে। খুঁজোওয়েব বাহ্যিক ওয়েবসাইটের তথ্য প্রদর্শন করলেও, এসব লিংকের কনটেন্ট, নির্ভুলতা বা নিরাপত্তার জন্য আমরা দায়ী নই। বাহ্যিক সাইটের গোপনীয়তা নীতি এবং শর্তাবলী তাদের নিজস্ব, যা আপনার অনুসরণ করা উচিত।

আমরা কোনো ব্যক্তিগত তথ্য, যেমন নাম, ইমেইল বা ফোন নম্বর সংগ্রহ করি না, এবং আপনার সার্চ ডেটা সংরক্ষণ করা হয় না। আপনার গোপনীয়তা আমাদের কাছে গুরুত্বপূর্ণ, এবং আমরা আমাদের গোপনীয়তা নীতি অনুসারে আপনার তথ্য সুরক্ষিত রাখার জন্য প্রতিশ্রুতিবদ্ধ।

আমরা সময়ে সময়ে আমাদের শর্তাবলী পরিবর্তন করতে পারি এবং এসব পরিবর্তন এই পৃষ্ঠায় প্রকাশ করা হবে। তাই, আমাদের শর্তাবলী নিয়মিত পর্যালোচনা করার পরামর্শ দেওয়া হচ্ছে। আপনি যদি খুঁজোওয়েব ব্যবহার চালিয়ে যান, তবে তা আমাদের শর্তাবলীর সাথে আপনার সম্মতির নির্দেশ দেবে। যদি আপনার কোনো প্রশ্ন থাকে, তাহলে আমাদের যোগাযোগ পাতা ব্যবহার করে আমাদের সাথে যোগাযোগ করতে পারেন।








</p>
            <div class="features">
                <div class="feature">
                    <h3>পরিষেবার গ্রহণযোগ্যতা</h3>
                    <p>খুঁজোওয়েব ব্যবহার করে, আপনি এই শর্তাবলীতে সম্মতি দিচ্ছেন। যদি আপনি এগুলোর সাথে একমত না হন, তবে অনুগ্রহ করে আমাদের সাইট ব্যবহার করবেন না।</p>
                </div>
                <div class="feature">
                    <h3>প্রশ্ন</h3>
                    <p>support@khujoweb.com</p>
                </div>
        </div>

        <!-- Footer -->
        <footer>
            <div class="footer-links">
                <a href="/index.php">প্রধান পাতা</a>
                <a href="/about.php">আমাদের সম্পর্কে</a>
                <a href="/privacy-policy.php">গোপনীয়তা নীতি</a>
            </div>
            <p>&copy; ২০২৫ খুঁজোওয়েব, সব অধিকার সংরক্ষিত।</p>
        </footer>
    </div>
</body>
<style>
    /* General styling */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    color: #333;
}

.wrapper {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
    text-align: center;
}

/* Logo and title */
.logo {
    margin-top: 50px;
}

.logo-img {
    height: 80px;
    width: auto;
}

.site-title {
    font-size: 36px;
    color: #2B587A;
    font-weight: bold;
    margin-top: 20px;
}

/* Search section */
.search-section {
    margin-top: 40px;
}

#search-input {
    width: 300px;
    padding: 10px;
    font-size: 18px;
    border: 2px solid #ddd;
    border-radius: 4px;
}

.search-button {
    padding: 10px 20px;
    font-size: 18px;
    background-color: #2B587A;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

.search-button:hover {
    background-color: #4e7e99;
}

/* About section */
.about-section {
    margin-top: 60px;
    background-color: #ffffff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.about-section h2 {
    font-size: 28px;
    color: #2B587A;
    margin-bottom: 20px;
}

.features {
    display: flex;
    justify-content: space-around;
    margin-top: 40px;
}

.feature {
    width: 30%;
    background-color: #f9f9f9;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.feature h3 {
    font-size: 20px;
    color: #2B587A;
    margin-bottom: 10px;
}

.feature p {
    font-size: 16px;
    color: #555;
}

/* Footer */
footer {
    margin-top: 60px;
    padding: 20px;
    background-color: #2B587A;
    color: white;
}

.footer-links {
    margin-bottom: 10px;
}

.footer-links a {
    color: white;
    text-decoration: none;
    margin: 0 10px;
    font-size: 16px;
}

.footer-links a:hover {
    text-decoration: underline;
}

footer p {
    font-size: 14px;
}

/* Responsive Design for Mobile */
@media screen and (max-width: 768px) {
    .logo-img {
        height: 70px;
    }

    .site-title {
        font-size: 28px;
    }

    .search-section {
        margin-top: 20px;
    }

    #search-input {
        width: 250px;
        font-size: 16px;
    }

    .search-button {
        font-size: 16px;
    }

    .about-section {
        margin-top: 40px;
        padding: 15px;
    }

    .features {
        flex-direction: column;
        align-items: center;
    }

    .feature {
        width: 80%;
        margin-bottom: 20px;
    }

    footer {
        padding: 15px;
    }

    .footer-links a {
        font-size: 14px;
    }

    footer p {
        font-size: 12px;
    }
}

@media screen and (max-width: 480px) {
    .search-button {
        padding: 8px 16px;
    }

    .footer-links a {
        font-size: 12px;
    }
}
</style>
</html>
