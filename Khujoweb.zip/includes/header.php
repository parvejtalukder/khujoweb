<!-- header.php -->
<header style="display: flex; justify-content: center; align-items: center; padding: 20px; background-color: #ffffff;">
    <p id="datetime" style="margin: 0; font-size: 18px; font-family: Arial, sans-serif; color: #333; text-align: center;"></p>
</header>

<script>
    function getBengaliDateTime() {
        const now = new Date();
        
        // Bengali numerals
        const bnNumbers = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];

        // Convert English numbers to Bengali
        function toBengaliNumber(num) {
            return num.toString().split('').map(digit => bnNumbers[digit] || digit).join('');
        }

        // Bengali month names
        const bnMonths = [
            "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন",
            "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"
        ];

        // Get date components
        const day = toBengaliNumber(now.getDate());
        const month = bnMonths[now.getMonth()];
        const year = toBengaliNumber(now.getFullYear());

        // Get time components
        let hours = now.getHours();
        const minutes = toBengaliNumber(now.getMinutes());
        const seconds = toBengaliNumber(now.getSeconds());
        const ampm = hours >= 12 ? "অপরাহ্ন" : "পূর্বাহ্ন";
        hours = hours % 12 || 12; // Convert to 12-hour format
        const bnHours = toBengaliNumber(hours);

        // Final formatted string
        const bnDateTime = `${day} ${month}, ${year} - ${bnHours}:${minutes}:${seconds} ${ampm}`;

        document.getElementById('datetime').textContent = bnDateTime;
    }

    setInterval(getBengaliDateTime, 1000); // Update every second
    getBengaliDateTime(); // Initial call
</script> 
    <div class="logo"> 
    <a href="https://bn.khujoweb.com">
        <img src="https://bn.khujoweb.com/kwb.png" alt="খুঁজোওয়েব লোগো">
    </a>
</div>