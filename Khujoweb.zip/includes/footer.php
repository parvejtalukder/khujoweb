<!-- footer.php -->
<footer>
    &copy; খুঁজোওয়েব
</footer>
