<!-- header.php -->
<header style="display: flex; justify-content: center; align-items: center; padding: 20px; background-color: #ffffff;">
    <p id="datetime" style="margin: 0; font-size: 14px; font-family: Arial, sans-serif; color: #333; text-align: center;"></p>
</header>

<script>
    function getBengaliDateTime() {
        const now = new Date();
        
        // Bengali numerals
        const bnNumbers = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];

        // Convert English numbers to Bengali
        function toBengaliNumber(num) {
            return num.toString().split('').map(digit => bnNumbers[digit] || digit).join('');
        }

        // Bengali month names
        const bnMonths = [
            "জানুয়ারি", "ফেব্রুয়ারি", "মার্চ", "এপ্রিল", "মে", "জুন",
            "জুলাই", "আগস্ট", "সেপ্টেম্বর", "অক্টোবর", "নভেম্বর", "ডিসেম্বর"
        ];

        // Get date components
        const day = toBengaliNumber(now.getDate());
        const month = bnMonths[now.getMonth()];
        const year = toBengaliNumber(now.getFullYear());

        // Get time components
        let hours = now.getHours();
        const minutes = toBengaliNumber(now.getMinutes());
        const seconds = toBengaliNumber(now.getSeconds());
        const ampm = hours >= 12 ? "অপরাহ্ন" : "পূর্বাহ্ন";
        hours = hours % 12 || 12; // Convert to 12-hour format
        const bnHours = toBengaliNumber(hours);

        // Final formatted string
        const bnDateTime = `${day} ${month}, ${year} - ${bnHours}:${minutes}:${seconds} ${ampm}`;

        document.getElementById('datetime').textContent = bnDateTime;
    }

    setInterval(getBengaliDateTime, 1000); // Update every second
    getBengaliDateTime(); // Initial call
</script> 

<div class="logo">
    <a href="https://bn.khujoweb.com/">
        <img src="https://bn.khujoweb.com/kwb.png" alt="খুঁজোওয়েব লোগো" class="logo-img">
    </a>
</div>

<style>
    .logo-img {
        width: 150px; /* Adjust the width to your preferred size */
        height: auto; /* Maintain aspect ratio */
    }

    body {
        font-family: 'Arial', sans-serif;
        background-color: #fff;
        color: #202124;
        margin: 0;
        padding: 0;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: flex-start;
        height: 100vh;
        overflow-x: hidden;
    }

    .search-results-container {
        width: 100%;
        max-width: 900px;
        margin-top: 30px;
        text-align: left;
        margin-bottom: 20px;
    }

    .search-result {
        background-color: #fff;
        border-bottom: 1px solid #e0e0e0;
        padding: 15px 20px;
        margin-bottom: 10px;
        box-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
        display: flex;
        flex-direction: row;
        align-items: center;
    }

    .search-result:hover {
        background-color: #f8f8f8;
    }

    .result-thumbnail {
        margin-right: 15px;
    }

    .thumbnail-img {
        width: 100px;  /* Adjust the size as per your need */
        height: 75px;
        object-fit: cover;
        border-radius: 5px;
    }

    .result-info {
        flex-grow: 1;
    }

    .result-link {
        color: #1a73e8;
        text-decoration: none;
        font-size: 18px;
    }

    .result-link:hover {
        text-decoration: underline;
    }

    .result-info p {
        font-size: 14px;
        color: #5f6368;
        line-height: 1.6;
    }

    .source-name {
        font-size: 12px;
        color: #888;
        margin-top: 8px;
    }

    footer {
        margin-top: 50px;
        font-size: 14px;
        color: #5f6368;
        text-align: center;
        width: 100%;
    }

    footer a {
        color: #1a73e8;
        text-decoration: none;
    }

    footer a:hover {
        text-decoration: underline;
    }

    .footer-container {
        padding: 10px 0;
        border-top: 1px solid #e0e0e0;
        width: 100%;
    }

    .pagination {
        display: flex;
        justify-content: center;
        margin-top: 20px;
    }

    .pagination button {
        margin: 0 5px;
        padding: 8px 16px;
        background-color: #1a73e8;
        color: white;
        border: none;
        cursor: pointer;
    }

    .pagination button:hover {
        background-color: #155ab1;
    }

    .pagination button:disabled {
        background-color: #ccc;
        cursor: not-allowed;
    }
</style>

<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>খুঁজোওয়েব - সার্চ ফলাফল</title>
        <link rel="shortcut icon" href="https://blog.khujoweb.com/wp-content/uploads/2025/01/cropped-cropped-Khujoweb-Icon.png">
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<script>
    // Define a list of Bengali bad words (updated with additional offensive words)
const badWords = [
    // 🟥 বাংলা অশ্লীল শব্দ
    'গালি', 'অশ্লীল', 'নফরৎ', 'ধর্ষণ', 'মাদক', 'হিংসা', 'অনৈতিক', 'জঘন্য',
    'সেক্স', 'চুদাচুদি', 'ব্যাভিচার', 'পর্ণ', 'নগ্ন', 'হস্তমৈথুন', 'পতিতা', 'পতিতালয়',
    'বেলেল্লাপনা', 'অশ্লীলতা', 'প্রাপ্তবয়স্ক', 'বিতৃষ্ণা', 'নোংরা', 'অসৎ', 'লম্পট',
    'নগ্নতা', 'যৌনতা', 'পতিবেশিনী', 'বালিকা যৌন', 'পরকীয়া', 'রতিক্রিয়া', 'উলঙ্গ',

    // 🟩 ইংরেজি অশ্লীল শব্দ
    'sex', 'hot sex', 'sexy', 'porn', 'nude', 'masturbate', 'escort', 'hooker', 
    'stripper', 'orgasm', 'hardcore', 'x-rated', 'explicit', 'adult', 'hentai',
    'xxx', 'vibrator', 'bdsm', 'gangbang', 'milf', 'cum', 'ejaculate', 'penetration',
    'blowjob', 'boobs', 'tits', 'pussy', 'cock', 'dildo', 'fetish', 'erotic', 
    'incest', 'anal', 'voyeur', 'taboo', 'camgirl', 'escort service', 'lingerie',

    // 🚫 প্রাপ্তবয়স্ক ওয়েবসাইট ব্লক
    'xnxx', 'xvideos', 'pornhub', 'redtube', 'brazzers', 'youporn', 'hclips', 
    'spankbang', 'fapster', 'pornhd', 'tnaflix', 'chaturbate', 'cam4', 'livejasmin', 
    'bangbros', 'playboy', 'hustler', 'bongacams', 'camsoda', 'onlyfans', 
    'erome', 'freeporn', 'sexvids', 'tube8', 'mofos', 'realitykings', 'evilangel', 
    'naughtyamerica', 'fakehub', 'teamSkeet', 'sxyprn', 'boobsrealm', 'pornmd',
    'adultfriendfinder', 'puretaboo', 'javhd', 'yespornplease', 'pornmaki',

    // 🔥 সহিংসতা ও অপরাধমূলক শব্দ (বাংলা)
    'খুন', 'মারামারি', 'নৃশংস', 'সন্ত্রাস', 'বোমা', 'আক্রমণ', 'জঙ্গি', 'নাশকতা',
    'চোর', 'ডাকাতি', 'অস্ত্র', 'হামলা', 'গুন্ডা', 'গ্যাং', 'খারাপ', 'নৃশংসতা', 
    'রক্তপাত', 'হত্যা', 'ধর্ষক', 'অপহরণ', 'ভয়াবহ', 'নির্যাতন', 'জেহাদ', 'গণহত্যা',

    // 🏴‍☠️ প্রতারণামূলক ওয়েবসাইট ও স্প্যাম
    'lottery', 'casino', 'betting', 'online betting', 'fake job', 'money scam', 
    'loan fraud', 'fake investment', 'pyramid scheme', 'crypto scam', 'blackhat',
    'forex fraud', 'ponzi scheme', 'counterfeit', 'hacking', 'spam website',
    'get rich quick', 'clickbait', 'phishing', 'carding', 'stolen data',

    // 🎰 জুয়া সংক্রান্ত ওয়েবসাইট ব্লক
    'bet365', '1xbet', 'pinnacle', 'betway', 'betfair', 'unibet', '888sport',
    'sportingbet', 'williamhill', 'sbobet', 'dafabet', 'parimatch', 'leovegas',
    '22bet', 'casumo', 'jackpotcity', '888casino', 'spinpalace', 'betonline',
    'pokerstars', 'blackjack', 'roulette', 'slotmachine', 'free spins', 'poker'
];
  let currentPage = 1;
        let currentQuery = "";
    function searchResults(query, page = 1) {
        const API_KEY = 'AIzaSyBiLnuZDXjHu6t2lN8FpA3MP5FBfgfqDIg';  // Your API Key
        const CX_KEY = '2263097502101497e';  // Replace with your Custom Search Engine ID
        const startIndex = (page - 1) * 10 + 1;
        const url = `https://www.googleapis.com/customsearch/v1?q=${encodeURIComponent(query)}&key=${API_KEY}&cx=${CX_KEY}&start=${startIndex}&safe=active`;

        fetch(url)
            .then(response => response.json())
            .then(data => {
                const results = data.items;
                const searchResultsContainer = document.getElementById('search-results');
                searchResultsContainer.innerHTML = ''; // Clear previous results

                if (results && results.length > 0) {
                    results.forEach(item => {
                        // Check if the result contains any bad Bengali words
                        let containsBadWords = false;
                        badWords.forEach(word => {
                            if (item.title.toLowerCase().includes(word) || item.snippet.toLowerCase().includes(word)) {
                                containsBadWords = true;
                            }
                        });

                        // If the result contains any bad words, skip it
                        if (containsBadWords) return;

                        const resultItem = document.createElement('div');
                        resultItem.classList.add('search-result');

                        // Adding the thumbnail image and source site name
                        const thumbnail = item.pagemap && item.pagemap.cse_image ? item.pagemap.cse_image[0].src : '';  // Empty string for no image
                        const siteName = new URL(item.link).hostname.replace('www.', '');

                        resultItem.innerHTML = `
                            <div class="result-thumbnail">
                                <img src="${thumbnail || 'https://via.placeholder.com/150'}" alt="${item.title}" class="thumbnail-img" onerror="this.style.display='none'">
                            </div>
                            <div class="result-info">
                                <a href="${item.link}" target="_blank" class="result-link">
                                    <h3>${item.title}</h3>
                                </a>
                                <p>${item.snippet}</p>
                                <span class="source-name">${siteName}</span>
                            </div>
                        `;
                        searchResultsContainer.appendChild(resultItem);
                    });

                    // Update pagination buttons
                    updatePagination(data.queries.nextPage, data.queries.previousPage);
                } else {
                    searchResultsContainer.innerHTML = '<p>কোনো ফলাফল পাওয়া যায়নি।</p>';
                }
            })
            .catch(error => {
                console.error('Error fetching search results:', error);
                document.getElementById('search-results').innerHTML = '<p>ফলাফল লোড করতে সমস্যা হয়েছে।</p>';
            });
    }

    // Update the pagination buttons based on the next page availability
    function updatePagination(nextPage, previousPage) {
        const paginationContainer = document.getElementById('pagination');
        paginationContainer.innerHTML = '';

        const prevButton = document.createElement('button');
        prevButton.textContent = 'পূর্ববর্তী';
        prevButton.disabled = !previousPage;
        prevButton.addEventListener('click', () => {
            if (currentPage > 1) {
                currentPage--;
                searchResults(currentQuery, currentPage);
            }
        });

        const nextButton = document.createElement('button');
        nextButton.textContent = 'পরবর্তী';
        nextButton.disabled = !nextPage;
        nextButton.addEventListener('click', () => {
            currentPage++;
            searchResults(currentQuery, currentPage);
        });

        paginationContainer.appendChild(prevButton);
        paginationContainer.appendChild(nextButton);
    }

    // Get the query parameter from the URL
    const urlParams = new URLSearchParams(window.location.search);
    const queryParam = urlParams.get('query');
    if (queryParam) {
        currentQuery = queryParam;
        searchResults(queryParam);
    }
</script>
    <div id="search-results" class="search-results-container">
        <!-- Search results will be injected here -->
    </div>

    <div id="pagination" class="pagination">
        <!-- Pagination buttons will be injected here -->
    </div>

     <!-- Footer -->
        <footer>
            <div class="footer-links">
                <a href="/about.php">আমাদের সম্পর্কে</a>
                <a href="/privacy-policy.php">গোপনীয়তা নীতি</a>
                <a href="/contact.php">যোগাযোগ</a>
                <a href="/tc.php">শর্তাবলী</a>
            </div>
            <p>&copy; ২০২৫ খুঁজোওয়েব, সব অধিকার সংরক্ষিত।</p>
        </footer>
        <style>
        /* Footer */
footer {
    margin-top: 60px;
    padding: 20px;
    background-color: #2B587A;
    color: white;
}

.footer-links {
    margin-bottom: 10px;
}

.footer-links a {
    color: white;
    text-decoration: none;
    margin: 0 10px;
    font-size: 16px;
}

.footer-links a:hover {
    text-decoration: underline;
}

footer p {
    font-size: 14px;
}
</style>

</body>
</html>
