<?php include('includes/header.php'); ?>

<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>খুঁজোওয়েব - বাংলা বান্ধব সার্চ ইঞ্জিন</title>
    <link rel="stylesheet" href="assets/style.css">
</head>
<body>
    <script>
    window.addEventListener('hashchange', function() {
    if (window.location.hash === 'search') {
        window.history.replaceState(null, null, ''); // Remove the hash from the URL
    }
}, false);
</script>
    <div class="search-container">
        <!-- গুগল প্রোগ্রামেবল সার্চ ইঞ্জিন -->
<script async src="https://cse.google.com/cse.js?cx=c10244d8b3e1843b9">
</script>
<div class="gcse-search"></div> 
    <style>
        body {
            background-color: white;
            font-family: Arial, sans-serif;
            margin: 0;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            height: 100vh;
            text-align: center;
        }

        .logo img {
            width: 300px;
            height: auto;
        }

        .search-container {
            margin-top: 20px;
            width: 80%;
            max-width: 600px;
        }

        footer {
            margin-top: 50px;
            font-size: 14px;
            color: #555;
        }
    </style>
</body>
</html>

<?php include('includes/footer.php'); ?>
