<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Khujoweb - Safe Search Engine for the Bengali Community</title>
    <meta name="description" content="Khujoweb is a safe and engaging visual search engine for the Bengali community, providing a safe and reliable online search experience.">
    <link rel="icon" href="/favicon.ico">
    <link rel="stylesheet" href="style.css">
    <script src="script.js" defer></script>
    <link rel="shortcut icon" href="https://blog.khujoweb.com/wp-content/uploads/2025/01/cropped-cropped-Khujoweb-Icon.png">
<link rel="icon" type="image/png" href="https://blog.khujoweb.com/wp-content/uploads/2025/01/cropped-cropped-Khujoweb-Icon.png" sizes="16x16">
<link rel="apple-touch-icon" sizes="180x180" href="https://blog.khujoweb.com/wp-content/uploads/2025/01/cropped-cropped-Khujoweb-Icon.png">
</head>
<body>
    <div class="wrapper">
        <!-- Logo -->
        <div class="logo">
            <img src="https://en.bhikitia.org/images/1/16/Khujoweb.png" alt="Khujoweb Logo" class="logo-img">
        </div>
        <!-- Search Section -->
        <div class="search-section">
            <form action="#" method="GET" onsubmit="return validateForm()">
                <input type="text" name="query" id="search-input" placeholder="Search for safe and trusted Bengali content...">
                <button type="submit" class="search-button">Search</button>
            </form>
        </div>

        <!-- About Section -->
        <div class="about-section">
            <h2>How Khujoweb Works</h2>
            <p>Khujoweb is a safe and engaging search engine designed specifically for the Bengali community. It offers a safe and reliable search experience, where we ensure that all content is family-friendly and culturally relevant.</p>
            <div class="features">
                <div class="feature">
                    <h3>Safe Search</h3>
                    <p>We filter out explicit and harmful content, ensuring that you have access to only safe, educational, and culturally appropriate material.</p>
                </div>
                <div class="feature">
                    <h3>Visual Results</h3>
                    <p>Our search results are displayed with large, colorful thumbnails, making it easier to identify relevant content. This is especially helpful for younger users.</p>
                </div>
                <div class="feature">
                    <h3>Community-Centered</h3>
                    <p>Khujoweb is designed for the Bengali community, offering content that resonates with the local culture and values, while maintaining privacy and security.</p>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <footer>
            <div class="footer-links">
                <a href="#">About Us</a>
                <a href="#">Privacy Policy</a>
                <a href="#">Contact Us</a>
                <a href="#">Community Guidelines</a>
            </div>
            <p>&copy; 2025 Khujoweb. All rights reserved.</p>
        </footer>
    </div>
</body>
<style>
    /* General styling */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    color: #333;
}

.wrapper {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
    text-align: center;
}

/* Logo and title */
.logo {
    margin-top: 50px;
}

.logo-img {
    height: 80px;
    width: auto;
}

.site-title {
    font-size: 36px;
    color: #2B587A;
    font-weight: bold;
    margin-top: 20px;
}

/* Search section */
.search-section {
    margin-top: 40px;
}

#search-input {
    width: 300px;
    padding: 10px;
    font-size: 18px;
    border: 2px solid #ddd;
    border-radius: 4px;
}

.search-button {
    padding: 10px 20px;
    font-size: 18px;
    background-color: #2B587A;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

.search-button:hover {
    background-color: #4e7e99;
}

/* About section */
.about-section {
    margin-top: 60px;
    background-color: #ffffff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.about-section h2 {
    font-size: 28px;
    color: #2B587A;
    margin-bottom: 20px;
}

.features {
    display: flex;
    justify-content: space-around;
    margin-top: 40px;
}

.feature {
    width: 30%;
    background-color: #f9f9f9;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.feature h3 {
    font-size: 20px;
    color: #2B587A;
    margin-bottom: 10px;
}

.feature p {
    font-size: 16px;
    color: #555;
}

/* Footer */
footer {
    margin-top: 60px;
    padding: 20px;
    background-color: #2B587A;
    color: white;
}

.footer-links {
    margin-bottom: 10px;
}

.footer-links a {
    color: white;
    text-decoration: none;
    margin: 0 10px;
    font-size: 16px;
}

.footer-links a:hover {
    text-decoration: underline;
}

footer p {
    font-size: 14px;
}

/* Responsive Design for Mobile */
@media screen and (max-width: 768px) {
    .logo-img {
        height: 70px;
    }

    .site-title {
        font-size: 28px;
    }

    .search-section {
        margin-top: 20px;
    }

    #search-input {
        width: 250px;
        font-size: 16px;
    }

    .search-button {
        font-size: 16px;
    }

    .about-section {
        margin-top: 40px;
        padding: 15px;
    }

    .features {
        flex-direction: column;
        align-items: center;
    }

    .feature {
        width: 80%;
        margin-bottom: 20px;
    }

    footer {
        padding: 15px;
    }

    .footer-links a {
        font-size: 14px;
    }

    footer p {
        font-size: 12px;
    }
}

@media screen and (max-width: 480px) {
    .search-button {
        padding: 8px 16px;
    }

    .footer-links a {
        font-size: 12px;
    }
}
</style>
</html>
