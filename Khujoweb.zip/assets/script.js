// script.js (optional for dynamic interactions)
document.addEventListener("DOMContentLoaded", function() {
    const searchButton = document.querySelector(".search-button");
    const searchBox = document.querySelector(".search-box");

    searchButton.addEventListener("click", function(event) {
        if (searchBox.value.trim() === "") {
            alert("Please enter a search term!");
        }
    });
});
